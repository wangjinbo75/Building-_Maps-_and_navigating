#include "camera_data.h"

int main(int argc, char *argv[])
{
    Camera info;
    //info.CaptureJpeg( IMAGEWIDTH,IMAGEHEIGHT);
    info.CapturePhotos();

    return 1;
   
   // int i=3;
  //  while(i--)
}
