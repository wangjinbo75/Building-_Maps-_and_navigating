#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QTimer>
#include <QPixmap>
#include <QImage>
#include <QPainter>

//#include <image.h>
#include <camera_data.h>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
       ui->setupUi(this);
    
       QPixmap pix;  //用来显示图片
       QByteArray aa ;

       BITMAPFILEHEADER   bf;
       BITMAPINFOHEADER   bi;
       //Set BITMAPINFOHEADER
       bi.biSize = 40;
       bi.biWidth = IMAGEWIDTH;
       bi.biHeight = IMAGEHEIGHT;
       bi.biPlanes = 1;
       bi.biBitCount = 24;
       bi.biCompression = 0;
       bi.biSizeImage = IMAGEWIDTH*IMAGEHEIGHT*3;
       bi.biXPelsPerMeter = 0;
       bi.biYPelsPerMeter = 0;
       bi.biClrUsed = 0;
       bi.biClrImportant = 0;


       //Set BITMAPFILEHEADER
       bf.bfType = 0x4d42;
       bf.bfSize = 54 + bi.biSizeImage;
       bf.bfReserved = 0;
       bf.bfOffBits = 54;

       Camera Cam;

       Cam.v4l2_grab();
       Cam.yuyv_to_rgb888();

       aa.append((char *)&bf,14);
       aa.append((char *)&bi,40);
       aa.append((char *)Cam.frame_buffer,640*480*3);
       pix.loadFromData(aa);
       ui->label->setPixmap(pix);

      // Cam.CloseCamera();
}

MainWindow::~MainWindow()
{
    delete ui;
}
