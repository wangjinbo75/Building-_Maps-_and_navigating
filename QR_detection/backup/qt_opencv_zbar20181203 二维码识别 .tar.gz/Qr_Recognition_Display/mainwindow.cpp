#include "mainwindow.h"
#include "ui_mainwindow.h"

using namespace std;
using namespace zbar;
//using namespace cv;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);


    cam     = NULL;
    timer   = new QTimer(this);
    scanner = new ImageScanner();
//    Cam   = new VideoCapture();
//   imag   = new QImage();         // 初始化

    scanner->set_config(zbar::ZBAR_NONE,zbar::ZBAR_CFG_ENABLE, 1);
    /*信号和槽*/
    connect(timer, SIGNAL(timeout()), this, SLOT(on_start_clicked()));  // 时间到，读取当前摄像头信息
    cam = cvCreateCameraCapture(0);//打开摄像头，从摄像头中获取视频
    timer->start(33);              // 开始计时，超时则发出timeout()信号
//    Cam.open(0);    //打开摄像头

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    QString fileName=QFileDialog::getOpenFileName(this,tr("Open Image"), ".",tr("Image Files(*.png *.jpg *.jpeg)"));
    image=cv::imread(fileName.toStdString());
    QImage img = QImage((const unsigned char*)(image.data),
                        image.cols, image.rows, QImage::Format_RGB888); //设定图像大小自适应label窗口的大小
    img = img.scaled(ui->label->size(), Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    ui->label->setPixmap(QPixmap::fromImage(img));
}

void MainWindow::on_start_clicked()
{

      frame = cvQueryFrame(cam);// 从摄像头中抓取并返回每一帧
//      cvSaveImage("frame0.jpg",frame);
//    cv::Mat imageGray = cv::imread("frame0.jpg", 1);



      IplImage* frame0  = cvCloneImage(frame);  //浅拷贝一下
      cv::Mat InitialImage = cv::cvarrToMat(frame0);  //cv MAT
//      cv::Mat partion_img(imageGray, cv::Rect(0, 0, 640,480));
//      cv::Mat resize(partion_img, imageGray,cv::Size(320, 0), 0, 0, cv::INTER_CUBIC);

       cv::Mat RGB2GRAYImg;
       cv::Mat DisplayImg;

       cv::cvtColor(InitialImage,RGB2GRAYImg,CV_BGR2GRAY);   //   转换成灰色 检查二维吗
       cv::cvtColor(InitialImage,DisplayImg,CV_BGR2RGB);    //    过滤颜色


      int width  = RGB2GRAYImg.cols;
      int height = RGB2GRAYImg.rows;
      uchar *raw = (uchar *) RGB2GRAYImg.data;
      Image imageZbar(width, height, "Y800", raw, width * height);
      scanner->scan(imageZbar); //掃描條碼

      Image::SymbolIterator symbol = imageZbar.symbol_begin();
      if (imageZbar.symbol_begin() == imageZbar.symbol_end())
      {
            cout << "width = "<< width<<"\n" ;
            cout << "rows = "<< height<<"\n" ;
            cout << "data = "<< &raw  <<"\n" ;
            cout << "Fail! Please check the picture again!" << endl;
      }

      for (int i=0; symbol != imageZbar.symbol_end(); ++symbol,i++)
      {
           cout<<"symbol ="<< i<<"\n";
          string type = symbol->get_type_name();
          string code = symbol->get_data();
          cout << "type：" << endl << type << endl << endl;
          cout << "code：" << endl << code << endl << endl;

         //获取定位点个数
          int pointCount = symbol->get_location_size();

          int max_loc_x = symbol->get_location_x(0);
          int max_loc_y = symbol->get_location_y(0);
          int min_loc_x = symbol->get_location_x(0);
          int min_loc_y = symbol->get_location_y(0);

          int thickness = 2;
                  //遍历所有定位点
          for (int i = 0; i < pointCount; i++) {

                  int cur_loc_x = symbol->get_location_x(i);
                  int cur_loc_y = symbol->get_location_y(i);
                  int next_loc_x = symbol->get_location_x((i + 1) % pointCount);
                  int next_loc_y = symbol->get_location_y((i + 1) % pointCount);
                  cout << '(' << cur_loc_x << ',' << cur_loc_y << ")" << endl;
                  cv::line(DisplayImg, cv::Point(cur_loc_x, cur_loc_y), cv::Point(next_loc_x, next_loc_y), cv::Scalar(0,255,0),
                       thickness);

                  if (cur_loc_x > max_loc_x) {
                      max_loc_x = cur_loc_x;
                  }
                  if (cur_loc_y > max_loc_y) {
                      max_loc_y = cur_loc_y;
                  }
                  if (cur_loc_x < min_loc_x) {
                      min_loc_x = cur_loc_x;
                  }
                  if (cur_loc_y < min_loc_y) {
                      min_loc_y = cur_loc_y;
                  }
           }
          cv::putText(DisplayImg, code, cv::Point(min_loc_x, min_loc_y),
                          cv::FONT_HERSHEY_SIMPLEX,
                          0.5, cv::Scalar(100, 255, 0),1);

          cout << min_loc_x << "," << min_loc_y << "," << max_loc_x << "," << max_loc_y << endl;

      }



 //         IplImage imgTmp = image1;
//            cout<<"2"<<"\n";
//           input = cvCloneImage(&imgTmp);
//          cout<<"3"<<"\n";
//        // 将抓取到的帧，转换为QImage格式。QImage::Format_RGB888不同的摄像头用不同的格式。
     // QImage::Format format;
      //QImage image((const uchar*)image1.data, image1.cols, image1.rows,QImage::Format_Indexed8);   //  灰度图
      QImage image((const uchar*)DisplayImg.data, DisplayImg.cols, DisplayImg.rows,QImage::Format_RGB888);
      ui->label->setPixmap(QPixmap::fromImage(image));  // 将图片显示到label上

      //test
      S = QString::number(state, 10);
      ui->label_num->setText(S);
      state++;
}
